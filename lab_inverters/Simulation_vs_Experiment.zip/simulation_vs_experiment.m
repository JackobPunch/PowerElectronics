clc;
clear all;

%%------------------------- OSCYLOSKOP ----------------------------------

% Ładowanie danych do przestrzeni roboczej z pliku wygenerowanego przez
% oscyloskp
Scope_Data = readtable('.\INPUT_DATA\SCOPE_DATA.CSV'); 


% Odczyt danych z poszczególnych kanałów oscyloskopu. 
% Pomijamy puste komórki oraz informacje o konfiguracji oscyloskopu.

Scope_CH1 = Scope_Data{25:end,1}; 
Scope_CH2 = Scope_Data{25:end,3}; 
Scope_CH3 = Scope_Data{25:end,5};  
Scope_CH4 = Scope_Data{25:end,7};  

% UsWprowadzić z ustawień oscyloskopu
Scope_Sample_Rate=1e-5; 

% Generowanie odpowiedniego wektora czasu dla próbek z oscyloskopu.
Record_Length = length(Scope_CH1); 
Scope_Time = 0:Scope_Sample_Rate:(Record_Length-1)*Scope_Sample_Rate; 

% Wyświetlanie danych z oscyloskopu
figure(1)
subplot(4,1,1)
plot(Scope_Time,Scope_CH1)
title('Scope Chanel 1')

subplot(4,1,2)
plot(Scope_Time,Scope_CH2)
title('Scope Chanel 2')

subplot(4,1,3)
plot(Scope_Time,Scope_CH3)
title('Scope Chanel 3')

subplot(4,1,4)
plot(Scope_Time,Scope_CH4)
title('Scope Chanel 4')

% --------------------------- SYMULACJA -----------------------------------

% Ładowanie danych do przestrzeni roboczej z pliku wygenerowanego przez
% Simulinka
Simulation_Data = load("INPUT_DATA\SIMULATION_DATA.mat");

% Zapis załadowanych danych w postaci pojedynczych wektorów. 
Simulation_Time = Simulation_Data.Simulation_Time; 
INVERTER_OUTPUT_CURRENT = Simulation_Data.INVERTER_OUTPUT_CURRENT; 
INVERTER_OUTPUT_VOLTAGE = Simulation_Data.INVERTER_OUTPUT_VOLTAGE; 
LOAD_CURRENT = Simulation_Data.LOAD_CURRENT; 
LOAD_VOLTAGE = Simulation_Data.LOAD_VOLTAGE; 

% Wyświetlanie danych z symulacji: 

figure(2)
subplot(4,1,1)
plot(Simulation_Time,LOAD_VOLTAGE)
title('Simulation Load Voltage')

subplot(4,1,2)
plot(Simulation_Time,LOAD_CURRENT)
title('Simulation Load Current')

subplot(4,1,3)
plot(Simulation_Time,INVERTER_OUTPUT_CURRENT)
title('Simulation Inverter Output Current')

subplot(4,1,4)
plot(Simulation_Time,INVERTER_OUTPUT_VOLTAGE)
title('Simulation Inverter Output Voltage')

%----------- PORÓWNANIE PRZEBIEGÓW --------------------------------------

% Wybór danych do porównania z pomiarów - interesujący nas zakres danych 

Data_Start_Point = 20e-3; % czas w sekundach 
Data_Stop_Point = 80e-3;  % czas w sekundach 

% Znajdujemy elementy mieszczące się w zadanym przedziale: 
ID_of_useful_Samples = Scope_Time > Data_Start_Point & Scope_Time < Data_Stop_Point;

% Skracamy wektory sygnałów do wybranego zakresu czasu
Scope_Time= Scope_Time(ID_of_useful_Samples);
Scope_CH1 = Scope_CH1(ID_of_useful_Samples); 
Scope_CH2 = Scope_CH2(ID_of_useful_Samples); 
Scope_CH3 = Scope_CH3(ID_of_useful_Samples); 
Scope_CH4 = Scope_CH4(ID_of_useful_Samples); 


% Podobny zabieg wykonujemy dla przebiegów z symulacji

Data_Start_Point = 0.035023; % czas w sekundach 
Data_Stop_Point  = 0.095072;  % czas w sekundach 

ID_of_useful_Samples = Simulation_Time > Data_Start_Point & Simulation_Time < Data_Stop_Point;
Simulation_Time = Simulation_Time(ID_of_useful_Samples);
INVERTER_OUTPUT_CURRENT = INVERTER_OUTPUT_CURRENT(ID_of_useful_Samples);
INVERTER_OUTPUT_VOLTAGE = INVERTER_OUTPUT_VOLTAGE(ID_of_useful_Samples); 
LOAD_CURRENT = LOAD_CURRENT(ID_of_useful_Samples); 
LOAD_VOLTAGE = LOAD_VOLTAGE(ID_of_useful_Samples); 





% Resetowanie wektorów czasu, tak aby zaczynały się od zera. 

Scope_Time_vector_length = length(Scope_Time); 
Scope_Time = 0:Scope_Sample_Rate:(Scope_Time_vector_length-1)*Scope_Sample_Rate; 

Simulation_Time_vector_length = length(Simulation_Time);
Simulation_Sample_Rate = Simulation_Time(2)-Simulation_Time(1);
Simulation_Time = 0:Simulation_Sample_Rate:(Simulation_Time_vector_length-1)*Simulation_Sample_Rate; 

% Wyświetlanie wyników po skróceniu wektorów
figure(3)

subplot(4,2,1)
plot(Scope_Time,Scope_CH1)
title('Scope Chanel 1')

subplot(4,2,3)
plot(Scope_Time,Scope_CH2)
title('Scope Chanel 2')

subplot(4,2,5)
plot(Scope_Time,Scope_CH3)
title('Scope Chanel 3')

subplot(4,2,7)
plot(Scope_Time,Scope_CH4)
title('Scope Chanel 4')

subplot(4,2,2)
plot(Simulation_Time,LOAD_VOLTAGE)
title('Simulation Load Voltage')

subplot(4,2,4)
plot(Simulation_Time,LOAD_CURRENT)
title('Simulation Load Current')

subplot(4,2,6)
plot(Simulation_Time,INVERTER_OUTPUT_CURRENT)
title('Simulation Inverter Output Current')

subplot(4,2,8)
plot(Simulation_Time,INVERTER_OUTPUT_VOLTAGE)
title('Simulation Inverter Output Voltage')


% Porównanie dwóch przebiegów na tym samym wykresie
figure(4)
plot(Scope_Time,Scope_CH1, 'r')
hold on 
grid on
plot(Simulation_Time,LOAD_VOLTAGE,'g')
legend('Experimental Data','Simulation Data')
title('fgfg')